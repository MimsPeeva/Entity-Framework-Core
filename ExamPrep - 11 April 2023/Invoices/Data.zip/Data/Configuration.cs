﻿namespace Invoices.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-PI68CL1\MSSQLSERVER01;Database=Invoices;Integrated Security=True;Encrypt=False";
    }
}
