﻿namespace ProductShop.Data
{
    public static class Configuration
    {
        public const string ConnectionString = @"Server=DESKTOP-PI68CL1\MSSQLSERVER01;Database=ProductShop;Integrated Security=True;Encrypt=False";
    }
}
