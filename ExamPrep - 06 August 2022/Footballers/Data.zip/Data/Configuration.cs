﻿namespace Footballers.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-PI68CL1\MSSQLSERVER01;Database=FootballersExam;Trusted_Connection=True";
    }
}
