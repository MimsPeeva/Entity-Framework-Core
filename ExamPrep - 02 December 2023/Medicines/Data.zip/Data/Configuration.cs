﻿namespace Medicines.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-PI68CL1\MSSQLSERVER01;Database=Medicines;Trusted_Connection=True";
    }
}
