﻿namespace P02_FootballBetting.Data.Common
{
    public class Class1
    {

    }
}